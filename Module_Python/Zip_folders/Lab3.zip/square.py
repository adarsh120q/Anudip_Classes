def sqr(a):
    return f"Square of {a} = {a**2}"

num = float(input("Enter the number: "))
print(sqr(num))