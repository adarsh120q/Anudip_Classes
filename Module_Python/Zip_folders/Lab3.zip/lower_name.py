name = input("Enter the name: ")

print(f"Name in lowercase: {name.lower()}")