num1, num2, num3, num4, num5= map(float, input("Enter five space seperated numbers: ").split())

print(f"The maximum number is: {max(num1, num2, num3, num4, num5)}")
print(f"The minimum number is: {min(num1, num2, num3, num4, num5)}")