num1, num2, num3 = map(float, input("Enter three space seperated numbers: ").split())

print(f"The largest number is: {max(num1, num2, num3)}.")