temp = float(input("Enter the temperature in Celcius: "))
print(f"Temperature in Fahrenheit is= {(temp*(9/5))+32}")