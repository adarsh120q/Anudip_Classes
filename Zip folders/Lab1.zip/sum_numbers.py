num1, num2 = map(int, input("Enter two space separated number: ").split())
print(f"Product of numbers= {num1*num2}\nSum of numbers= {num1+num2}")