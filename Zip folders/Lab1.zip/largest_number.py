a = 10
b = 20

largest = a if a > b else b
print(f"The largest number is: {larger}")
