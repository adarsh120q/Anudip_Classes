num = float(input("Enter a number: "))
x = num
while num != 0:
    num = float(input("Enter another number: "))
    x+=num
print("Sum of numbers: ",x)